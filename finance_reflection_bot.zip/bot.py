from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters
import datetime
import re
import asyncio

spending_data = {}

async def log_spending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    now = datetime.datetime.now()

    if user_id not in spending_data:
        spending_data[user_id] = []

    spending_data[user_id].append({"timestamp": now, "text": text})
    await update.message.reply_text("Записал. Спасибо за честность!")

async def daily_prompt(app):
    while True:
        now = datetime.datetime.now()
        if now.hour == 21 and now.minute == 0:
            for user_id in spending_data:
                try:
                    await app.bot.send_message(user_id, "💸 На что ты потратил(а) деньги сегодня, о чём жалеешь?")
                except:
                    pass
            await asyncio.sleep(60)
        await asyncio.sleep(30)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    now = datetime.datetime.now()
    week_ago = now - datetime.timedelta(days=7)
    logs = spending_data.get(user_id, [])
    week_logs = [log for log in logs if log["timestamp"] >= week_ago]

    amounts = []
    categories = []
    for log in week_logs:
        text = log["text"]
        match = re.search(r"(\d+[.,]?\d*)", text)
        if match:
            amount = float(match.group(1).replace(",", "."))
            amounts.append(amount)
        categories.append(text.lower())

    common_words = {}
    for c in categories:
        for word in ["доставка", "кофе", "перекус", "подписка"]:
            if word in c:
                common_words[word] = common_words.get(word, 0) + 1

    common_text = ", ".join([f"{k} ({v})" for k, v in common_words.items()]) or "нет паттернов"

    avg = f"{sum(amounts)/len(amounts):.0f}" if amounts else "—"

    await update.message.reply_text(
        f"🧾 За 7 дней:\n- Записей: {len(week_logs)}\n- Средняя сумма: {avg} ₽\n- Часто: {common_text}"
    )

app = ApplicationBuilder().token("YOUR_TELEGRAM_BOT_TOKEN").build()
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, log_spending))
app.add_handler(CommandHandler("stats", stats))
app.job_queue.run_once(lambda _: asyncio.create_task(daily_prompt(app)), 1)
app.run_polling()
